eval $(starship init zsh)
