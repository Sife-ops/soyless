prompt adam2 8bit
