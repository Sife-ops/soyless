alias cfrf="$EDITOR ~/.config/zsh/conf.d/files.zsh"
alias cfdy="$EDITOR ~/.config/zsh/conf.d/directories.zsh"
alias cfv="$EDITOR ~/.config/nvim/init.vim"
alias cfa="$EDITOR ~/.config/aliasrc"
alias cfz="$EDITOR ~/.config/zsh/.zshrc"
alias rfb="$EDITOR ~/Documents/bookmarks"


