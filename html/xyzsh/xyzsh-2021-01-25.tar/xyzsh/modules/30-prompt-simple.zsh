PS1="%B%{$fg[magenta]%}%(4~|.../%3~|%~) %{$fg[blue]%}>%{$reset_color%}%b "
