# neofetch --ascii_distro MacOS_small
# neofetch --ascii_distro Linux
# neofetch --ascii_colors 8 3 7 --source $SARBS/ascii/templeos_big
# neofetch --ascii_colors 8 3 7 --source $SARBS/ascii/templeos

