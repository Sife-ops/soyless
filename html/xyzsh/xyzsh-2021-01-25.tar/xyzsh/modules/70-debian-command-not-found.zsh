source /etc/zsh_command_not_found >/dev/null 2>&1
