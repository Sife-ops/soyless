# put programs you want to run in every new shell in here
