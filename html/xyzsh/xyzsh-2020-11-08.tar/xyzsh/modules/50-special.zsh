# Use beam shape cursor on startup and for each new prompt.
function preexec() {
    echo -ne '\e[5 q'
}

# Automatically ls after cd
function chpwd() {
    # emulate -L zsh

    # if which ranger 1>/dev/null 2>&1; then
    #     ranger_cd
    # elif which lf 1>/dev/null 2>&1; then
    #     lf_cd
    # else
    #    ls -ahN --color=auto --group-directories-first
    # fi

    ls -ahN --color=auto --group-directories-first
}


