
autoload -U compinit && compinit
_comp_options+=(globdots)

autoload -U edit-command-line
zle -N edit-command-line

autoload -U promptinit && promptinit
autoload -U colors && colors
PS1="%B%{$fg[red]%}[%{$fg[yellow]%}%n%{$fg[green]%}@%{$fg[blue]%}%M %{$fg[magenta]%}%~%{$fg[red]%}]%{$reset_color%}$%b "
