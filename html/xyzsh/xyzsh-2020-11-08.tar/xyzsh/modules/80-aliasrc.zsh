#
# Sife's .aliasrc
#

# #--- COMMAND OPTIONS ---# #

alias \
    ccat="highlight --out-format=ansi" \
    cp="cp -iv" \
    diff="diff --color=auto" \
    ffmpeg="ffmpeg -hide_banner" \
    grep="grep --color=auto" \
    less='less -i' \
    ls="ls -ahN --color=auto --group-directories-first" \
    mv="mv -iv" \
    mkd="mkdir -pv" \
    rm="rm -vI" \
    yt="youtube-dl --add-metadata -i" \
    yta="yt -x -f bestaudio/best"

# #--- ABBREVIATIONS ---# #

# General
alias \
    cal='calcurse' \
    chx='chmod +x' \
    d='dragon-drag-and-drop' \
    e='emacs -nw' \
    f='nnn_auto_cd' \
    fcl='fc-list : family style | less' \
    ff='sudo find / -iname' \
    fvm='sudo fuser -vm' \
    irssi="irssi --home=${XDG_CONFIG_HOME:-$HOME/.config}/irssi" \
    k='kill' \
    ka="killall" \
    ll='ls -la --color=auto' \
    lynx='lynx -vikeys' \
    mutt='neomutt' \
    nb='newsboat' \
    nc='ncmpcpp' \
    offlineimap="offlineimap -c \\
        ${XDG_CONFIG_HOME:-$HOME/.config}/offlineimap/offlineimaprc" \
    p="sudo pacman" \
    pg='pgrep' \
    pk='pkill' \
    r='ranger_auto_cd' \
	ref="shortcs.sh >/dev/null; \
        source ${XDG_CONFIG_HOME:-$HOME/.config}/zsh/shortcutrc ; \
        source ${XDG_CONFIG_HOME:-$HOME/.config}/zsh/zshnameddirrc" \
    sa="source ${XDG_CONFIG_HOME:-$HOME/.config}/zsh/aliasrc" \
	sdn="sudo shutdown -h now" \
    so="source" \
    sz="source ${XDG_CONFIG_HOME:-$HOME/.config}/zsh/.zshrc" \
    sze="source ${XDG_CONFIG_HOME:-$HOME/.config}/zsh/.zshenv" \
    td='transmission-daemon' \
    tp='trash-put' \
    tr="transmission-remote" \
    tremc='ddspawn.sh -x 1x1 -c 1,1 -o 100 -l 6 tremc' \
    YT="youtube-viewer" \
    xo='xdg-open' \
    xr='xrdb ~/.Xresources' \
    z="zathura"

# Git
alias \
    gc='git commit' \
    gcm='git commit -m' \
    gch='git checkout --' \
    gd='git diff' \
    gdh='git diff HEAD' \
    gi="git status --porcelain | grep '^??' | cut -c4- >> .gitignore" \
    gl='git ls-tree -r master --name-only' \
    glu='git ls-files --others --exclude-standard' \
    glua='git ls-files --others' \
    gp='git push -u origin master' \
    gr='git rebase -i' \
    grl='git rev-list --pretty=oneline --abbrev-commit HEAD' \
    grh='git reset --hard' \
    gs='git status' \
    gt='git add' \
    gu='git add -u' \
    gut='git rm -r --cached'

# Vim
command -v nvim >/dev/null \
    && alias vim="nvim" v="nvim" vimdiff="nvim -d"  \
    || alias v="vim"

# Tmux
alias \
	t="tmux -f ${XDG_CONFIG_HOME:-$HOME/.config}/tmux/tmux.conf" \
    ta='tmux attach-session -t' \
    tk='tmux kill-session -t' \
    tl='tmux list-sessions' \
	tmux="tmux -f ${XDG_CONFIG_HOME:-$HOME/.config}/tmux/tmux.conf"
