source /usr/share/fzf/completion.zsh 2>/dev/null
source /usr/share/fzf/key-bindings.zsh 2>/dev/null

# export FZF_ALT_C_COMMAND="locate '*'"
# export FZF_CTRL_T_COMMAND="locate '*'"

if [ -d /var/lib/relocate ]; then
    export FZF_DEFAULT_COMMAND="cat /var/lib/relocate/relocate{d,f}.db"
    export FZF_ALT_C_COMMAND="cat /var/lib/relocate/relocated.db"
    export FZF_CTRL_T_COMMAND="cat /var/lib/relocate/relocate{d,f}.db"
fi
