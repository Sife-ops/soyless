source /usr/share/zsh/plugins/zsh-autosuggestions/zsh-autosuggestions.zsh 2>/dev/null
source /usr/share/zsh-autosuggestions/zsh-autosuggestions.zsh 2>/dev/null # Debian
ZSH_AUTOSUGGEST_HIGHLIGHT_STYLE="fg=10"

