source /usr/share/doc/pkgfile/command-not-found.zsh 2>/dev/null
